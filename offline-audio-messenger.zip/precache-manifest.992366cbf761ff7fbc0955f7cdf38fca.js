self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "040e518d92e5e63b86d941d0f08c640e",
    "url": "./index.html"
  },
  {
    "revision": "b0542db5e16d56e21222",
    "url": "./static/css/main.0837612c.chunk.css"
  },
  {
    "revision": "c1de9fa26c578f4ebf91",
    "url": "./static/js/2.2b099c9c.chunk.js"
  },
  {
    "revision": "b0542db5e16d56e21222",
    "url": "./static/js/main.c1dd1a82.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "06d100cbc80aa1ed3a7643005794fda7",
    "url": "./static/media/NotoSans-Regular.06d100cb.eot"
  },
  {
    "revision": "aa283550181a649994822d16dd2d8e91",
    "url": "./static/media/NotoSans-Regular.aa283550.woff2"
  },
  {
    "revision": "edbefd4189c1916795792fcfa9c08e11",
    "url": "./static/media/NotoSans-Regular.edbefd41.ttf"
  },
  {
    "revision": "fbe46f26a3381739983bef1da5c94fbd",
    "url": "./static/media/NotoSans-Regular.fbe46f26.woff"
  }
]);